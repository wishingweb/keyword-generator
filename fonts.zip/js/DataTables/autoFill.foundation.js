
$.fn.dataTable.AutoFill.classes.btn = 'button tiny';
